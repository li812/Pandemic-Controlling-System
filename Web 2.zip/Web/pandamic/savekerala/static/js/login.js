




function login()
{
document.querySelector('.login-container').style.display = 'flex';
document.querySelector('.signup-container').style.display = 'none';
}
function closse()
{
document.querySelector('.login-container').style.display = 'none';
}
function signup()
{
document.querySelector('.signup-container').style.display = 'flex';
document.querySelector('.login-container').style.display = 'none';
}
function closse1()
{
document.querySelector('.signup-container').style.display = 'none';
}