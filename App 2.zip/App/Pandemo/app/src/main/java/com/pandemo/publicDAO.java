package com.pandemo;

public class publicDAO {
    String pubid,pubname,addharno,addharcopy,pubdob,pubcontact,pubemail,pubaddress,pubjob,pubjobsector,pubjobdescrp,pubphoto,pubstatus,location,distict,login;

    public publicDAO(String pubid, String pubname, String addharno, String addharcopy, String pubdob, String pubcontact, String pubemail, String pubaddress, String pubjob, String pubjobsector, String pubjobdescrp, String pubphoto, String pubstatus, String location, String distict, String login) {
        this.pubid = pubid;
        this.pubname = pubname;
        this.addharno = addharno;
        this.addharcopy = addharcopy;
        this.pubdob = pubdob;
        this.pubcontact = pubcontact;
        this.pubemail = pubemail;
        this.pubaddress = pubaddress;
        this.pubjob = pubjob;
        this.pubjobsector = pubjobsector;
        this.pubjobdescrp = pubjobdescrp;
        this.pubphoto = pubphoto;
        this.pubstatus = pubstatus;
        this.location = location;
        this.distict = distict;
        this.login = login;
    }

    public String getPubid() {
        return pubid;
    }

    public void setPubid(String pubid) {
        this.pubid = pubid;
    }

    public String getPubname() {
        return pubname;
    }

    public void setPubname(String pubname) {
        this.pubname = pubname;
    }

    public String getAddharno() {
        return addharno;
    }

    public void setAddharno(String addharno) {
        this.addharno = addharno;
    }

    public String getAddharcopy() {
        return addharcopy;
    }

    public void setAddharcopy(String addharcopy) {
        this.addharcopy = addharcopy;
    }

    public String getPubdob() {
        return pubdob;
    }

    public void setPubdob(String pubdob) {
        this.pubdob = pubdob;
    }

    public String getPubcontact() {
        return pubcontact;
    }

    public void setPubcontact(String pubcontact) {
        this.pubcontact = pubcontact;
    }

    public String getPubemail() {
        return pubemail;
    }

    public void setPubemail(String pubemail) {
        this.pubemail = pubemail;
    }

    public String getPubaddress() {
        return pubaddress;
    }

    public void setPubaddress(String pubaddress) {
        this.pubaddress = pubaddress;
    }

    public String getPubjob() {
        return pubjob;
    }

    public void setPubjob(String pubjob) {
        this.pubjob = pubjob;
    }

    public String getPubjobsector() {
        return pubjobsector;
    }

    public void setPubjobsector(String pubjobsector) {
        this.pubjobsector = pubjobsector;
    }

    public String getPubjobdescrp() {
        return pubjobdescrp;
    }

    public void setPubjobdescrp(String pubjobdescrp) {
        this.pubjobdescrp = pubjobdescrp;
    }

    public String getPubphoto() {
        return pubphoto;
    }

    public void setPubphoto(String pubphoto) {
        this.pubphoto = pubphoto;
    }

    public String getPubstatus() {
        return pubstatus;
    }

    public void setPubstatus(String pubstatus) {
        this.pubstatus = pubstatus;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getDistict() {
        return distict;
    }

    public void setDistict(String distict) {
        this.distict = distict;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }
}
